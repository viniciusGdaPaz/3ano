
//função para carregar as disciplinas do curso
function carregarDisciplinas(){
   var xhttp = new XMLHttpRequest();
   xhttp.open("GET", "/lpw/crud_alunos_ajax/api/listar_por_curso.php?id=3", false);
   xhttp.send();
   var resposta = xhttp.responseText;
   alert(resposta);
}



//FunçãocriarOption -> será chamada durante a implementação
function criarOption(elem, value, label, valueSelected) {
    var option = document.createElement('option');
    option.setAttribute("value", value);
    option.innerHTML = label;

    if(value == valueSelected)
        option.selected = true;

    elem.appendChild(option);
}

