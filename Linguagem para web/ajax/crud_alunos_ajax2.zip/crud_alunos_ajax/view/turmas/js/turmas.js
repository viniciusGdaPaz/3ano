
//função para carregar as disciplinas do curso
function carregarDisciplinas(){
   //PEGAR O SELECT com as disciplinas
   var selDisciplinas = document.getElementById('selDisciplina');
   selDisciplinas.innerHTML = "";
   criarOption(selDisciplinas, 0, "----Selecione----", 0);

    //Pegar o id do curso q o usuario selecionou
    var idCurso = document.getElementById('selCurso').value;
    var url = "/lpw/crud_alunos_ajax/api/listar_por_curso.php?id="+idCurso;


    //REQUISIÇÃO AJAX
   var xhttp = new XMLHttpRequest();
   xhttp.open("GET", url, false);
   xhttp.send();
   var resposta = xhttp.responseText;
  // alert(resposta);

  var disciplinas = JSON.parse(resposta);
  
  for(var x=0; x<disciplinas.length; x++){
    var disc = disciplinas[x];
    criarOption(selDisciplinas, disc.id, disc.codigo +" - "+disc.nome, 0);

    
  }
}



//FunçãocriarOption -> será chamada durante a implementação
function criarOption(elem, value, label, valueSelected) {
    var option = document.createElement('option');
    option.setAttribute("value", value);
    option.innerHTML = label;

    if(value == valueSelected)
        option.selected = true;

    elem.appendChild(option);
}

