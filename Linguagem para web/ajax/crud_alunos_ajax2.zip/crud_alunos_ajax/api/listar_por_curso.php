<?php

include_once(__DIR__."/../controller/DisciplinaController.php");

//Receber o id do curso por metodo get
$id = 0;

if(isset($_GET["id"])){
    $id = $_GET["id"];
}

//Chamar o diciplina controle
$discCont = new DisciplinaController();
$disciplina = $discCont->listarPorCurso($id);

//print_r($disciplina);
echo json_encode($disciplina, JSON_PRETTY_PRINT| JSON_UNESCAPED_UNICODE);
?>