<?php
include_once(__DIR__."/include/header.php");
?>

<form action="POST">
    <div>
        <label for="nickName">NickName:</label>
        <input type="text" name="nickName" id="nickName">
    </div>

    <div>
        <label for="classe">Classe:</label>
        <select name="Classe" id="Classe">
            <option value="">Selecione a sua Classe</option>
            <option value="Guerreiro">Guerreiro</option>
            <option value="Mago">Mago</option>
            <option value="Assassino">Assassino</option>
            <option value="Paladino">Paladino</option>
        </select>
    </div>

    <div>
        <label for="Item">Item:</label>
        <select name="Item" id="Item">
            <option value="">Selecione o seu Item</option>
            <option value="1">Espada do Guerreiro</option>
            <option value="2">Cajado do Mago</option>
            <option value="3">Escudo do Paladino</option>
            <option value="4">Adaga do Assassino</option>
            <option value="5">Armadura de Guerreiro</option>
            <option value="6">Anel do Mago</option>
        </select>
    </div> 

    <h1>Distribua os pontos (5) de acordo com a sua preferência</h1>

    <!-- Mensagem para mostrar pontos restantes -->
    <p id="pontosRestantes">Pontos restantes: 5</p>

    <div>
        <label for="vida">Vida:</label>
        <input type="number" name="vida" id="vida" min="0" max="5" value="0" onchange="atualizarPontos()" oninput="atualizarPontos()">
    </div>

    <div>
        <label for="attack">Ataque:</label>
        <input type="number" name="attack" id="attack" min="0" max="5" value="0" onchange="atualizarPontos()" oninput="atualizarPontos()">
    </div>

    <div>
        <label for="defense">Defesa:</label>
        <input type="number" name="defense" id="defense" min="0" max="5" value="0" onchange="atualizarPontos()" oninput="atualizarPontos()">
    </div>
</form>

<script>
function atualizarPontos() {
    const maxPontos = 5;

    // Obtém os valores dos campos
    const vida = parseInt(document.getElementById("vida").value) || 0;
    const attack = parseInt(document.getElementById("attack").value) || 0;
    const defense = parseInt(document.getElementById("defense").value) || 0;

    // Calcula a soma total dos pontos
    const totalUsado = vida + attack + defense;

    // Atualiza a mensagem de pontos restantes
    const pontosRestantes = maxPontos - totalUsado;
    const mensagem = document.getElementById("pontosRestantes");

    mensagem.textContent = `Pontos restantes: ${pontosRestantes}`;

   
}
</script>

<?php
include_once(__DIR__."/include/footer.php");
?>
