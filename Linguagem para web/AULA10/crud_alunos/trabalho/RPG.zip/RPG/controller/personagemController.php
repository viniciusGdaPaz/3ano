<?php
include(__DIR__.'/../model/Personagem.php');
include(__DIR__.'/../service/personagemService.php'); 
include(__DIR__.'/../dao/personagemDAO.php');


class PersonagemController{

    private $personagemDao;
    private $personagemService;

    public function __construct(){
        $this->personagemDao = new PersonagemDAO();
        $this->personagemService = new PersonagemService();
    }


    public function inserir(Personagem $personagem){
        $this->personagemDao->insert($personagem);
    }
}