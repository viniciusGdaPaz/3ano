<?php
include(__DIR__.'/../util/Connection.php');
include(__DIR__.'/../model/Personagem.php');

class PersonagemDao{
    private $conn;

    public function __construct(){
        $this->conn = Connection::getConnection();
    }

    public function insert(Personagem $personagem){
        $sql = 'INSERT INTO personagem (nickname, vida, attack, defense, id_classe, id_item) VALUES (?, ?, ?, ?, ?, ?)';
        $stm = $this->conn->prepare($sql);
        $stm->execute([$personagem->getNickname(), $personagem->getVida(), $personagem->getAttack(), $personagem->getDefense(), $personagem->getClasse()->getId(), $personagem->getItem()->getId()]);
    }
}

?>